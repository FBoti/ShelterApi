﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShelterApi.Models;
using ShelterApi.Models.DTOs;

namespace ShelterApi.Controllers;

[Route("animals")]
public class AnimalsController : ControllerBase
{
    private readonly AnimalshelterContext _context;

    public AnimalsController(AnimalshelterContext context)
    {
        _context = context;
    }

    [HttpPost("newAnimal")]
    public async Task<IActionResult> NewAnimal([FromBody] NewAnimalDto dto)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(dto.Name) || string.IsNullOrWhiteSpace(dto.Species) || dto.Age < 0 || dto.Weight <= 0)
            {
                return BadRequest(new { message = "Hibás adatok: a név és a faj kötelező, az életkor nem lehet negatív, a súly pozitív szám legyen.", result = (object?)null });
            }

            if (!await _context.Shelters.AnyAsync(s => s.Id == dto.ShelterId))
            {
                return NotFound(new { message = "A megadott menhely nem található.", result = (object?)null });
            }

            if (await _context.Animals.AnyAsync(a => a.ShelterId == dto.ShelterId && a.Name == dto.Name && a.Species == dto.Species))
            {
                return Conflict(new { message = "Ebben a menhelyben már van ilyen nevű és fajú állat.", result = (object?)null });
            }

            var animal = new Animal
            {
                Id = Guid.NewGuid(),
                Name = dto.Name,
                Species = dto.Species,
                Age = dto.Age,
                Weight = dto.Weight,
                RegTime = DateTime.Now,
                ShelterId = dto.ShelterId
            };

            _context.Animals.Add(animal);
            await _context.SaveChangesAsync();

            return StatusCode(201, new { message = "Az állat sikeresen rögzítve.", result = animal });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { message = "Szerverhiba: " + ex.Message, result = (object?)null });
        }
    }

    [HttpGet("allAnimal")]
    public async Task<IActionResult> AllAnimal()
    {
        try
        {
            var animals = await _context.Animals.ToListAsync();

            if (animals.Count == 0)
            {
                return NotFound(new { message = "Nincs rögzített állat.", result = (object?)null });
            }

            return Ok(new { message = "Az állatok listája.", result = animals });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { message = "Szerverhiba: " + ex.Message, result = (object?)null });
        }
    }

    [HttpGet("byId")]
    public async Task<IActionResult> ById([FromQuery] Guid id)
    {
        try
        {
            var animal = await _context.Animals.FirstOrDefaultAsync(a => a.Id == id);

            if (animal == null)
            {
                return NotFound(new { message = "Nincs ilyen azonosítójú állat.", result = (object?)null });
            }

            return Ok(new { message = "Az állat adatai.", result = animal });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { message = "Szerverhiba: " + ex.Message, result = (object?)null });
        }
    }

    [HttpPut("update")]
    public async Task<IActionResult> Update([FromQuery] Guid id, [FromBody] UpdateAnimalDto dto)
    {
        try
        {
            var animal = await _context.Animals.FirstOrDefaultAsync(a => a.Id == id);

            if (animal == null)
            {
                return NotFound(new { message = "Nincs ilyen azonosítójú állat.", result = (object?)null });
            }

            if (string.IsNullOrWhiteSpace(dto.Name) || string.IsNullOrWhiteSpace(dto.Species) || dto.Age < 0 || dto.Weight <= 0)
            {
                return BadRequest(new { message = "Hibás adatok: a név és a faj kötelező, az életkor nem lehet negatív, a súly pozitív szám legyen.", result = (object?)null });
            }

            if (!await _context.Shelters.AnyAsync(s => s.Id == dto.ShelterId))
            {
                return NotFound(new { message = "A megadott menhely nem található.", result = (object?)null });
            }

            if (await _context.Animals.AnyAsync(a => a.Id != id && a.ShelterId == dto.ShelterId && a.Name == dto.Name && a.Species == dto.Species))
            {
                return Conflict(new { message = "Ebben a menhelyben már van ilyen nevű és fajú állat.", result = (object?)null });
            }

            animal.Name = dto.Name;
            animal.Species = dto.Species;
            animal.Age = dto.Age;
            animal.Weight = dto.Weight;
            animal.ShelterId = dto.ShelterId;

            await _context.SaveChangesAsync();

            return Ok(new { message = "Az állat adatai módosultak.", result = animal });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { message = "Szerverhiba: " + ex.Message, result = (object?)null });
        }
    }

    [HttpDelete("deleteAnimal")]
    public async Task<IActionResult> DeleteAnimal([FromQuery] Guid id)
    {
        try
        {
            var animal = await _context.Animals.FirstOrDefaultAsync(a => a.Id == id);

            if (animal == null)
            {
                return NotFound(new { message = "Nincs ilyen azonosítójú állat.", result = (object?)null });
            }

            _context.Animals.Remove(animal);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Az állat törölve lett.", result = animal });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { message = "Szerverhiba: " + ex.Message, result = (object?)null });
        }
    }
}